describe("test test", function() {
    it('should pass', function() {
        expect(true).toEqual(true);
    });
});

describe("InMemoryStorage", function() {
    it('should create InMemoryStorage', function() {
        expect(typeof InMemoryStorage).toEqual("object");
    })
});